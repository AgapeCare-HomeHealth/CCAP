using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CCAP.Infrastructure.Migrations;

public partial class PatientCommunicationAndAudit : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<string>("ContactType", "CallNotes", type: "nvarchar(100)", maxLength: 100, nullable: false, defaultValue: "");
        migrationBuilder.AddColumn<string>("Method", "CallNotes", type: "nvarchar(50)", maxLength: 50, nullable: false, defaultValue: "");
        migrationBuilder.AlterColumn<string>("Notes", "CallNotes", type: "nvarchar(max)", nullable: false, oldClrType: typeof(string), oldType: "nvarchar(max)", oldMaxLength: 5000);

        migrationBuilder.CreateTable(
            name: "PatientAuditLogs",
            columns: table => new
            {
                PatientAuditLogId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PatientId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PerformedByUserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                OccurredAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                EntityType = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                EntityId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                Action = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                OldValues = table.Column<string>(type: "nvarchar(max)", nullable: true),
                NewValues = table.Column<string>(type: "nvarchar(max)", nullable: true),
                Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true)
            }, constraints: table =>
            {
                table.PrimaryKey("PK_PatientAuditLogs", x => x.PatientAuditLogId);
                table.ForeignKey("FK_PatientAuditLogs_Patients_PatientId", x => x.PatientId, "Patients", "PatientId", onDelete: ReferentialAction.Cascade);
                table.ForeignKey("FK_PatientAuditLogs_ApplicationUsers_PerformedByUserId", x => x.PerformedByUserId, "ApplicationUsers", "UserId", onDelete: ReferentialAction.Restrict);
            });
        migrationBuilder.CreateIndex("IX_PatientAuditLogs_PatientId_OccurredAt", "PatientAuditLogs", new[] { "PatientId", "OccurredAt" });
        migrationBuilder.CreateIndex("IX_PatientAuditLogs_PerformedByUserId", "PatientAuditLogs", "PerformedByUserId");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("PatientAuditLogs");
        migrationBuilder.DropColumn("ContactType", "CallNotes");
        migrationBuilder.DropColumn("Method", "CallNotes");
        migrationBuilder.AlterColumn<string>("Notes", "CallNotes", type: "nvarchar(max)", maxLength: 5000, nullable: false, oldClrType: typeof(string), oldType: "nvarchar(max)");
    }
}
