using Microsoft.EntityFrameworkCore.Migrations;
#nullable disable
namespace CCAP.Infrastructure.Migrations;
public partial class PatientCareTracking:Migration
{
 protected override void Up(MigrationBuilder m){m.CreateTable(name:"PatientCareLogs",columns:t=>new{PatientCareLogId=t.Column<Guid>(type:"uniqueidentifier",nullable:false),PatientId=t.Column<Guid>(type:"uniqueidentifier",nullable:false),RecordedByUserId=t.Column<Guid>(type:"uniqueidentifier",nullable:true),LogType=t.Column<string>(type:"nvarchar(50)",maxLength:50,nullable:false),Item=t.Column<string>(type:"nvarchar(200)",maxLength:200,nullable:false),Quantity=t.Column<decimal>(type:"decimal(18,2)",nullable:true),Unit=t.Column<string>(type:"nvarchar(50)",maxLength:50,nullable:true),RecordedAt=t.Column<DateTime>(type:"datetime2",nullable:false),Notes=t.Column<string>(type:"nvarchar(2000)",maxLength:2000,nullable:true)},constraints:t=>{t.PrimaryKey("PK_PatientCareLogs",x=>x.PatientCareLogId);t.ForeignKey("FK_PatientCareLogs_Patients_PatientId",x=>x.PatientId,"Patients","PatientId",onDelete:ReferentialAction.Cascade);t.ForeignKey("FK_PatientCareLogs_ApplicationUsers_RecordedByUserId",x=>x.RecordedByUserId,"ApplicationUsers","UserId",onDelete:ReferentialAction.Restrict);});m.CreateIndex("IX_PatientCareLogs_PatientId_LogType_RecordedAt","PatientCareLogs",new[]{"PatientId","LogType","RecordedAt"});m.CreateIndex("IX_PatientCareLogs_RecordedByUserId","PatientCareLogs","RecordedByUserId");}
 protected override void Down(MigrationBuilder m)=>m.DropTable("PatientCareLogs");
}
