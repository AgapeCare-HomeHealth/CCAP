﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CCAP.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PatientProfileWorkflowUpdates : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_NotificationReadStates_UserId",
                table: "NotificationReadStates");

            migrationBuilder.CreateIndex(
                name: "IX_PatientCareLogs_RecordedByUserId",
                table: "PatientCareLogs",
                column: "RecordedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientAuditLogs_PerformedByUserId",
                table: "PatientAuditLogs",
                column: "PerformedByUserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_PatientCareLogs_RecordedByUserId",
                table: "PatientCareLogs");

            migrationBuilder.DropIndex(
                name: "IX_PatientAuditLogs_PerformedByUserId",
                table: "PatientAuditLogs");

            migrationBuilder.CreateIndex(
                name: "IX_NotificationReadStates_UserId",
                table: "NotificationReadStates",
                column: "UserId");
        }
    }
}
