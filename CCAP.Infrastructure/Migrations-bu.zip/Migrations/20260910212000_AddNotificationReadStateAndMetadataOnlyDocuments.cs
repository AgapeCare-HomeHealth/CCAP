using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CCAP.Infrastructure.Migrations;

public partial class AddNotificationReadStateAndMetadataOnlyDocuments : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<string>(
            name: "StorageKey",
            table: "ReferralDocuments",
            type: "nvarchar(500)",
            maxLength: 500,
            nullable: true,
            oldClrType: typeof(string),
            oldType: "nvarchar(500)",
            oldMaxLength: 500);

        // The first revision temporarily created this table through an
        // idempotent startup initializer. Keep this migration safe for
        // databases that already contain that table.
        migrationBuilder.Sql("""
            IF OBJECT_ID(N'dbo.NotificationReadStates', N'U') IS NULL
            BEGIN
                CREATE TABLE dbo.NotificationReadStates
                (
                    NotificationReadStateId uniqueidentifier NOT NULL
                        CONSTRAINT PK_NotificationReadStates PRIMARY KEY,
                    UserId uniqueidentifier NOT NULL,
                    NotificationId uniqueidentifier NOT NULL,
                    NotificationType nvarchar(50) NOT NULL,
                    ReadAt datetime2 NOT NULL,
                    CONSTRAINT FK_NotificationReadStates_ApplicationUsers_UserId
                        FOREIGN KEY (UserId)
                        REFERENCES dbo.ApplicationUsers(UserId)
                        ON DELETE CASCADE
                );
            END

            IF NOT EXISTS (
                SELECT 1 FROM sys.indexes
                WHERE name = N'UX_NotificationReadStates_User_Notification'
                  AND object_id = OBJECT_ID(N'dbo.NotificationReadStates'))
            BEGIN
                CREATE UNIQUE INDEX UX_NotificationReadStates_User_Notification
                    ON dbo.NotificationReadStates
                    (UserId, NotificationId, NotificationType);
            END

            IF NOT EXISTS (
                SELECT 1 FROM sys.indexes
                WHERE name = N'IX_NotificationReadStates_UserId'
                  AND object_id = OBJECT_ID(N'dbo.NotificationReadStates'))
            BEGIN
                CREATE INDEX IX_NotificationReadStates_UserId
                    ON dbo.NotificationReadStates(UserId);
            END
            """);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "NotificationReadStates");

        migrationBuilder.AlterColumn<string>(
            name: "StorageKey",
            table: "ReferralDocuments",
            type: "nvarchar(500)",
            maxLength: 500,
            nullable: false,
            oldClrType: typeof(string),
            oldType: "nvarchar(500)",
            oldMaxLength: 500,
            oldNullable: true);
    }
}
